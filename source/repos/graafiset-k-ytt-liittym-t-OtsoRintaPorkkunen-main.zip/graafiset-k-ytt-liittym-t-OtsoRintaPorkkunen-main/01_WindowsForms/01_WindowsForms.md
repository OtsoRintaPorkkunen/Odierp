# 01_WindowsFormsPerusteet

Toteuta oheisten kovien mukainen Windws Forms käyttöliittymä (dialogi).
Toiminnallisuutta ei vielä tarvitse toteuttaa. *Huom!* Huomaatko mitään ulkoasuun liittyvä heikkouksia esimerkissä?

![dialogi1](dialogi.png)

Kuva 1. Päänäkymä

![menubar1](menubar1.png)

Kuva 2. Menubar tiedosto

![menubar2](menubar2.png)

Kuva 3. Menubar tietoja
