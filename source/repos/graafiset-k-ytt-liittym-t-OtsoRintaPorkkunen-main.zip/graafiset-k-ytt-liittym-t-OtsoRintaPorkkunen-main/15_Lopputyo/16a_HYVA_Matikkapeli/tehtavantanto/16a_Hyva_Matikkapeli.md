# 16 Matikkapeli (hyvä arvosana)

Tee matikkapelistä graafinen versio käyttäen Windows Formsseja. (Jos teit aiemmalla 
kurssilla aritmetiikkatehtävän konsolille, voit hyödyntää suoraan sen koodia).

Ohjelmassa tulee olla:
1. pääikkuna jossa käyttäjä valitsee pelityypin,
2. jokaiselle laskutyypille oma ikkunansa (Form), jotka kaikki eroavat visuaalisesti 
toisistaan,
3. ikkuna tai ikkunat josta käyttäjä voi käydä tarkistamassa huipputuloksiaan, tai 
kertyneitä palkintojaan pelityyppikohtaisesti. Nämä ikkunat tai ikkunan osat tulisi 
myös erottua toisistaan visuaalisesti.
*HUOM!* Ikkunoita varten kannattaa tehdä yliluokkana template/malli lomake, josta muut 
lomakeikkunat periytyvät. Näin ulkoasu pysyy yhtenäisenä ja muutosten teko on 
nopeaa.

Mieti aluksi miten ratkaiset nämä ongelmat/kehitysehdotukset?
* Voiko lomakkeelle laittaa ääntä?
* Miten tarkistat kuka käyttäjä on pelaamassa? Tarvitsetko käyttäjätunnuksia?
* Saavutusten (huipputulokset tai palkinnot) tallennus?
Tehtävässä ei tarvitse käyttää tietokantaa vaan tiedot voi tallentaa .txt tiedostoon. 
Jos haluat voit toki käyttää esim. SQL Serveriä palkintotietojen tallennukseen.

Vinkki: Kuinka siirtää tietoa lomakkeiden välillä:
https://grantwinney.com/passing-data-between-two-forms-in-winforms
