# 16_Jätkänshakki (kiitettävä arvosana)

Jätkänshakki on kahden pelaajan ristinolla-pelin versio, jossa pelaajan tehtävänä on 
saada viisi merkkiään (O tai X) riviin johonkin ilmansuuntaan.

1. Pelilaudan koko tulee olla pelaajan määritettävissä (joissain järkevissä rajoissa).
2. Pelin voi toteuttaa joko pelinä konetta vastaan tai kahden pelaajan pelinä.
Huomaa että yksinpelin toteuttaminen vaatii sinulta jonkinlaisen tekoälyn 
laatimista ja on siis huomattavasti haastavampi vaihtoehto.
3. Ohjelman tulee tutkia jokaisen siirron jälkeen, tuliko pelaajan rivi täyteen (eli viisi 
merkkiä pystyyn, vaakaan tai vinottain) ja, mikäli näin on, ilmoittaa voittaja.
4. Pelejä tulee voida pelata useampia, jolloin voittaja on esimerkiksi paras viidestä
tai
vaihtoehtoisesti pelata ruutu täyteen ja katsoa lopuksi kummalle tuli enemmän 
viiden merkin suoria.

*Huom!* Luo pelialue grafiikkana, eli älä käytä designeriä nappien luomiseen.
Aloita pelin suunnittelu tekemällä käyttötapauskaavio. Käytä kaaviota eri 
käyttöliittymänäkymien havainnollistamiseen