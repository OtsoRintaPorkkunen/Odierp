# 16_Muistipeli (hyvä tai kiitettävä arvosana)

## Versio 1 (hyvä arvosana)

Tee muistipeli, jossa pelilauta muodostuu korteista, joiden alla on kuva tai symboli. 
1. Pelaaja kääntää joka kierroksella kaksi korttia, ja yrittää muistelemalla edellisillä 
kierroksella näkemiään kääntöjä löytää kaksi samaa korttia.
2. Peli on kaksinpeli jossa kortteja arvataan vuorottain.
3. Voittaja on se, joka on kerännyt eniten pareja.
HUOM! Piirrä pelialue ohjelmallisesti, eli älä käytä Form Designeriä korttien
luomiseen.
Aloita peli suunnittelemalla käyttötapauskaavio. Käytä kaaviota eri 
käyttöliittymänäkymien havainnollistamiseen.

## Versio 2 (kiitettävä arvosana)

Täydennä ja parantele Versiota 1 ja lisää seuraavat toiminnot.
1. Käyttäjä voi valita joko yhden tai kahden pelaajan version.
2. Pelilaudan kokoa pystyy muuttamaan. (Ainakin kaksi eri pelivaihtoehtoa, esim. 
4x4 korttia ja 6x6 korttia.)
3. Pelikorttien aihealue valittavissa ainakin kolmesta vaihtoehdosta. (Esim. eläimet, 
työkalut, jne…)
4. Peli pitää kirjaa jokaisen pelaajan parhaasta tuloksisesta pelityypeittäin ja 
tallentaa ne tiedostoon tai SQL tietokantaan