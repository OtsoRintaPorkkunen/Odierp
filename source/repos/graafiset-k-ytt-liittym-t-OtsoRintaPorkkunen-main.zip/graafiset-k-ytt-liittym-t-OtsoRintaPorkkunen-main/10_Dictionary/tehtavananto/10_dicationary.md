# 10_Dictionary

Kirjoita Windows Forms -ohjema, jonka formissa on toiminnot Dictionary-rakenteen luontia, Key/Value-parien lisäämistä, talletettujen Value-arvojen haku Key-indeksin avulla sekä näiden tulostamista varten (Kuva 1.).  

![kuva](https://github.com/Gradia-Ohjelmistokehitys-k2022/graafiset-kayttoliittymat-pohja/blob/main/10_Dictionary/kuvat/dictionary01.png)

Kuva 1. Pääformi 

a) Kirjoita ensin Dictionaryn luontitoiminto. Kun formissa olevaa Luo Dictionary -nappia klikataan, niin napin tapahtumankäsittelijässä luodaan dictionary, johon voidaan tallentaa String-tyyppisiä Key/Value-pareja (Kuvan 1-1). 

- Testaa ohjelman toimivuus tässä vaiheessa eli varmista debuggerin                         avulla, että dictionary tulee luoduksi. 


b) Lisää formiin toiminto, jolla voi lisätä uusia Key/Value-pareja dictionaryyn. Kun Key ja Value kenttiin syötetään arvot (Tekstiä) ja klikataan Lisää-nappia, niin napin tapahtumankäsittelijässä lisätään kyseinen Key/Value-pari dictionaryyn. 

- Tarkista jälleen debuggerin avulla, että Key/Value-pari talentuu dictionaryyn! 

c) Lisää formiin toiminto, jolla voidaan Key:n avulla hakea Value-arvoja dictionarysta ja tulostaa ne formissa olevaan Label-komponenttiin. 

 
