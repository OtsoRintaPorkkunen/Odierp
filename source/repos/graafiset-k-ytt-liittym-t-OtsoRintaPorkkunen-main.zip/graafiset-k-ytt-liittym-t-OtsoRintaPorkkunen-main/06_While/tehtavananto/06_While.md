# 06While
1. Kirjoita Windows Forms -ohjelma, jonka formissa on nappi (Kuva 1-1). Kun nappia klikataan, niin napin tapahtumankäsittelijässä mennään while-luuppiin, jossa jokaisella kierroksella kysytään, että jatketaanko luupissa kiertämistä vai ei. Kysyminen suoritetaan messupoksin avulla, jossa on 'Yes' ja 'No' napit (Kuva 1-2). Jos klikataan 'Yes'-nappia, niin while-luupissa suoritetaan uusi kierros. Jos klikataan 'No'-nappia, niin while-luupista tullaan ulos. 

While-luuppi on kätevä silloin, kun etukäteen ei tiedetään luupin kierrosten lukumäärää. 


![while01](https://github.com/Gradia-Ohjelmistokehitys-k2022/graafiset-kayttoliittymat-pohja/blob/main/06_While/kuvat/while01.png)

Kuva 1. Pääformi

![while02](https://github.com/Gradia-Ohjelmistokehitys-k2022/graafiset-kayttoliittymat-pohja/blob/main/06_While/kuvat/while02.png)

Kuva 2. Messageboksi

